int myadd(int a, int b)
{
	int ans1;
	ans1 = a + b;
	return ans1;
}
