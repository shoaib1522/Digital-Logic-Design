int mysub(int x, int y)
{
	int ans2;
	ans2 = x - y;
	return ans2;
}
