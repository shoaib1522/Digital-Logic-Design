int myadd(int, int);
int mysub(int, int);
